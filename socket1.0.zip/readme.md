Open directory "./server" and "./client" separately.
Run the python file respectively.
You will get the prediction jpg where file "client_photo.py" is located.

						Socket1.0
						Modified on 2020/5/8
